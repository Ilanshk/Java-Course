package homework3;
/**
 * 
 * @author Ilan Shklover, Shira Cohen
 * Describes  which type of food are the animals and the plants.
 *
 */
public enum EFoodType {
  MEAT,NOTFOOD,VEGETABLE;
}
