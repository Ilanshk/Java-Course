package homework3;
import homework3.IEdible;
import homework3.EFoodType;
import homework3.Mobile;
import homework3.Point;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.locks.Lock;

import javax.imageio.ImageIO;

import homework3.IDiet;
/**
 * 
 * An abstract class that defines the characteristics common to all animals
 * @author Shira Cohen 211777834 & Ilan Shklover 206753550
 * 
 *
 */

public abstract class Animal extends Mobile implements IEdible,IDrawable, IAnimalBehavior,Runnable{
	
	/**
	 * name of the animal
	 */
	private String name; 
	/**
	 * weight of the animal
	 */
	private double weight; 
	/**
	 * Carnivore, Omnivore, Herbivore
	 */
	private IDiet diet; 
	private final int EAT_DISTANCE = 5;
	private int size;
	private String col;
	private int horSpeed;
	private int verSpeed;
	private boolean coordChanged;
	private int x_dir;
	private int y_dir;
	private int eatCount;
	private ZooPanel pan;
	private BufferedImage img1, img2;
	protected Thread thread; 
	protected boolean threadSuspended;
	public final static String PICTURE_PATH = "C:/Users/Ilan Shklover/OneDrive/����� ������/assignment2_pictures";
	//"C:\Users\Ilan Shklover\OneDrive\����� ������\assignment2_pictures\bea_b_1.png"
	//"C:/Users/Ilan Shklover/Desktop/assignment2_pictures";

	/***
	 * Constructor with name and point
	 * @param name 
	 * - name of the animal
	 * @param point
	 * - Point type object: int x, int y
	 */
	public Animal(String name, Point point) {
		super(point);
		this.name = name;
	}
	
	
	public Animal(int size,Point point) {
		super(point);
		this.size = size;
		this.x_dir = 1;//moves right
		this.y_dir = 1;// moves up
		//this.thread = new Thread();
		
	}
	
	
	public void start() {
		thread.start();
	}
	
	
	
	
	
	/**
	 * return the weight of the animal
	 * @return the weight of the animal as a double
	 */
    public double get_weight() {
    	return this.weight;
    }
    /**
     * set the idet and return true or false if the update was successful
     * @param idet -The type of animal- Carnivore, Omnivore, Herbivore
     * @return true if the update was successful, else- return false
     */
    public boolean set_diet(IDiet idet) {
    	this.diet = idet;
    	return true;
    }
    /**return the diet- the type of animal- Carnivore, Omnivore, Herbivore
     * 
     * @return the diet
     */
    public IDiet get_diet() {
    	return this.diet;
    }
    /**
     * set the weight of the animal and return true or false if the update was successful
     * @param weight 
     * - weight of the animal
     * @return true if the update was successful, else- return false
     */
	public boolean set_weight(double weight) {
		if(weight > 0)
		{
			this.weight = weight;
			return true;
		}
		return false;
		
	}
	/**
	 * Set the total distance of the animal
	 * @param distance - the distance the animal move
	 */
	public void addTotalDistance(double distance) {
		super.set_totalDistance(distance);
	}
	/**
	 * abstract method- A method that makes the sounds of the animals after they have eaten
	 */
	public abstract  void makeSound();
	/**
	 * Returns the calculation of the distance as a double, by Pythagoras' theorem
	 * @param point - the point to which the animal wants to move
	 * @return - return the calculation of the distance
	 */
	
	public double calcDistance(Point point) {
		if(Point.cheackBounderies(point) == true)
			return Math.sqrt(Math.pow(point.get_x(), 2)+Math.pow(point.get_y(),2))- Math.sqrt(Math.pow(super.getLocation().get_x(), 2)+Math.pow(super.getLocation().get_y(),2));
		else
			return 0;
	}
	/**
	 * Returns the distance between the current location and the destination point. Updates the weight of the animal
	 * @param destination- the point to which the animal wants to move
	 * @return - the distance between the current location and the destination point
	 */
	public double move(Point destination) {
		if(Math.abs(this.calcDistance(destination)) > 0) {
			this.addTotalDistance(Math.abs(calcDistance(destination)));
			super.setLocation(destination);
			this.set_weight(this.weight-(this.calcDistance(destination)*this.weight*0.00025));
			return this.calcDistance(destination);
		}
		return 0; // The animal did not move.
	}
	/**
	 * Abstract method- return the type of food
	 */
	public abstract EFoodType getFoodtype();
	/**
	 * 
	 * Abstract method- return the name of class
	 */
	public abstract String get_name_of_class();
	/**
	 * Returns true if the animal eats the food and the animal makes her voice heard. Else return false
	 * @param food- type of food: MEAT or PLANT
	 * @return true if the animal eats the food. Else return false
	 */
	public boolean eat(IEdible food) {
		double change = diet.eat(this, food);
		if(change !=0) {
			this.set_weight(change);
			makeSound();
			return true;
	
		}
		return false;
	}
	
	public void eatInc() {
		this.eatCount +=1;
	}
	/**
	 * @return the name of the animal
	 */
	public String get_name() {
		return name;
	}
	
	public int get_size() {
		return size;
	}
	
	public int get_speedHor() {
		return horSpeed;
	}
	
	public int get_speedVer() {
		return verSpeed;
	}
	
	public String get_color() {
		return col;
	}
	
	public int getX_dir() {
		return this.x_dir;
	}
	
	public int getY_dir() {
		return this.y_dir;
	}
	

	
	public boolean set_size(int size) {
		this.size = size;
		return true;
		
	}
	
	public boolean set_speedHor(int speed_h) {
		this.horSpeed = speed_h;
		return true;
	}
	
	public boolean set_speedVer(int speed_v) {
		this.verSpeed = speed_v;
		return true;
	}
	
	
	public boolean set_color(String color) {
		this.col = color;
		return true;
	}
	
	public boolean set_X_dir(int direction) {
		this.x_dir = direction;
		this.get_zoo_panel().repaint();
		return true;		
	}
	
	public boolean set_Y_dir(int direction) {
		this.y_dir = direction;
		this.get_zoo_panel().repaint();
		return true;
	}
	
	
	public void setSuspended() {
		threadSuspended = true;
	}
	
	public void setResumed() {
		
		synchronized(this) {
			threadSuspended = false;
			this.notifyAll();
		}
	}
	
	public  ZooPanel get_zoo_panel() {
		return this.pan;
	}
	
	public Thread get_thread() {
		return this.thread;
	}
	
	public int getSize() {
		return this.size;
	}
	
	public void setChanges(boolean state) {
		this.coordChanged =state;
		
	}
	
	public boolean getChanges() {
		return this.coordChanged;
	}
	
	
	public int getEatCount() {
		return this.eatCount;
	}
	
	public boolean set_getCount(int count) {
		 this.eatCount = count;
		 return true;
		
	}
	public boolean setZooPanel(ZooPanel zp) {
		this.pan = zp;
		return true;
	}
	
	public void set_thread() {
		Animal a = this;
		this.thread = new Thread(a);
	}
	
	
	public void loadImages(String nm) {
		try {
		if(this.get_color() == "Red") {
			 img1 = ImageIO.read(new File(PICTURE_PATH+"/"+nm+"_r_1.png"));
			 img2 = ImageIO.read(new File(PICTURE_PATH+"/"+nm+"_r_2.png"));
		}
		else if(this.get_color() == "Blue")
		{
			img1 = ImageIO.read(new File(PICTURE_PATH+"/"+nm+"_b_1.png"));
			img2 = ImageIO.read(new File(PICTURE_PATH+"/"+nm+"_b_2.png"));
		}
		else if(this.get_color() == "Natural") {
			img1 = ImageIO.read(new File(PICTURE_PATH+"/"+nm+"_n_1.png"));
			img2 = ImageIO.read(new File(PICTURE_PATH+"/"+nm+"_n_2.png"));
		}
			
		}
    	catch (IOException e) { System.out.println("Cannot load image"); }
		//"C:\Users\Ilan Shklover\Desktop\assignment2_pictures\grf_r_1.png"
    }
	
	public void drawObject (Graphics g) {
		 if(this.getX_dir()==1)
			 g.drawImage(img1, this.getLocation().get_x()-this.get_size()/2, this.getLocation().get_y()-this.get_size()/10, this.get_size()/2, this.get_size(), this.get_zoo_panel());
		 else 
			 g.drawImage(img2, this.getLocation().get_x(), this.getLocation().get_y()-this.get_size()/10, this.get_size()/2, this.get_size(), this.get_zoo_panel());
		if(this.getY_dir() == -1) // animal has to go up
			g.drawImage(img1,this.getLocation().get_x()-this.get_size()/2,this.getLocation().get_y()-this.get_size()/10,this.get_size()/2,this.get_size(),this.get_zoo_panel());
	}
	public String getColor() {
		return col;
	}
	
	//public abstract boolean check_color(Color col);
	
	@Override
	public  void run() {
		while(true) {
			try {
				Thread.sleep(1000);
				if(this.threadSuspended == true) {
					synchronized(this) {
						this.wait();
					}
				}
				else {//
					synchronized(this) {
						this.setLocation(new Point(this.getLocation().get_x()+ this.get_speedHor()*this.getX_dir(),this.getLocation().get_y()+ this.get_speedHor()*this.getY_dir()));
						//this.get_zoo_panel().repaint();
						if(this.getLocation().get_x() == this.get_zoo_panel().getWidth()) {
							this.set_X_dir(-1);
							//this.setLocation(this.getLocation());
							//this.get_zoo_panel().repaint();
						}
						else if(this.getLocation().get_y() == this.get_zoo_panel().getHeight()){
							this.set_Y_dir(-1);
	
							//this.get_zoo_panel().repaint();
						}
						else {
							this.get_zoo_panel().repaint();
							System.out.println(getLocation());
						}
					}
				}//
				//if(this.threadSuspended == false) {
					//synchronized(this) {
						//this.notifyAll();
					//}
				//}
					
			}
			catch(InterruptedException ex) {}
			//this.setLocation(new Point(this.getLocation().get_x()+ this.get_speedHor()*this.getX_dir(),this.getLocation().get_y()+ this.get_speedHor()*this.getY_dir()));
			//this.get_zoo_panel().repaint();
			if(this.getLocation().equals(new Point(this.get_zoo_panel().getWidth(),this.get_zoo_panel().getHeight())))
				this.get_zoo_panel().repaint();
				
		}
	}
}
		
	

		
	

	

