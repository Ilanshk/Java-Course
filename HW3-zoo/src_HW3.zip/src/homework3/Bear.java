package homework3;
import homework3.EFoodType;
import homework3.IEdible;
import homework3.Ilocatable;
import homework3.Mobile;
import homework3.Point;
import homework3.Plant;
import homework3.MessageUtility;

import java.awt.Color;

import homework3.Omnivore;
/**
 * The bear is all food(Omnivore). The initial weight is 408.2 kilograms, 
 * its initial location is x=100, y=5
 *  the color of the fur of the bears can be only black or white or gray. Default gray
 *  @author Shira Cohen 211777834 & Ilan Shklover 206753550
 *
 */
public class Bear extends RoarAnimals{
	/**
	 * default location
	 */
	private static final Point default_location = new Point(100, 5);
	/**
	 * fur color of the bear
	 */
	private String furColor; 
	/**
	 * Constructor with name, point and fur color. The initial weight is 408.2 kilograms,  
	 * the color of the fur of the bears can be only black or white or gray. Default gray
	 * @param name- name of the bear
	 * @param point- the location of the bear
	 * @param furColor- the fur color of the bear
	 */
	public Bear(String name, Point point, String furColor) {
		super(name,point);
		super.set_weight(308.2);
		
		if(furColor.equals(FurColor.BLACK) || furColor.equals(FurColor.WHITE) || furColor.equals(FurColor.GRAY))
			this.furColor = furColor;
		else {
			this.furColor = FurColor.GRAY.toString();
		}
		super.set_diet(new Omnivore());
		MessageUtility.logConstractor(this.get_name_of_class(), this.get_name());

	}
	/**
	 * Constructor with name, point and fur color.
	 * @param name- name of the bear
	 * @param point- the location of the bear
	 */
	public Bear(String name,Point point) {
		super(name,point);
		MessageUtility.logConstractor(this.get_name_of_class(), this.get_name());
		super.set_diet(new Omnivore());
	}
    /**
     * Constructor with name.
     * @param name - name of the bear
     */
	public Bear(String name) {
		super(name, default_location);
		this.furColor = FurColor.GRAY.toString();
		super.set_weight(308.2);
		MessageUtility.logConstractor(this.get_name_of_class(), this.get_name());
		super.set_diet(new Omnivore());

	}
	
	
	public Bear(int size,int speedHor,int speedVer,String color,ZooPanel zp) {
		super(size,default_location);
		super.set_speedHor(speedHor);
		super.set_speedVer(speedVer);
		super.set_color(color);
		super.set_weight(size* 1.5);
		super.setZooPanel(zp);
		super.loadImages("bea");
		super.setChanges(true);
		super.set_diet(new Omnivore());
		this.get_zoo_panel().repaint();
		
	}
	
	public Bear(int size,int speedHor,int speedVer,String color) {
		super(size,default_location);
		super.set_speedHor(speedHor);
		super.set_speedVer(speedVer);
		super.set_color(color);
		super.set_weight(size* 1.5);
	}
	
	
	
	/**
	 * Return the type of bear
	 * @return the type of bear
	 */
	public EFoodType getFoodtype() {
		MessageUtility.logGetter(this.get_name(), "getFoodtype", EFoodType.MEAT);
		return EFoodType.MEAT;
	}
	/**
	 * Return the name of class
	 * @return the name of class
	 */
	public String get_name_of_class() {
		MessageUtility.logGetter(this.get_name(), "get_name_of_class", "Bear");
		return "Bear";
	}
	/**
	 * print the sound of bear after he ate
	 */
	public void roar() {
		MessageUtility.logSound(super.get_name(),"Stands on its hind legs, roars and scratches its belly");
	}
    /**
     * Return the name of bear and the class- Bear
     * @return the name of bear and the class
     */
	public String toString() {
		return "[" + this.get_name_of_class() +"]:\n"+"Size:"+super.get_size()+"\n"
				+"Speed horizontal:"+super.get_speedHor()+"\n"
				+"Speed vertical:"+super.get_speedVer()+"\n"
				+"Color:"+super.get_color()+"\n";
	}
	public void loadImages(String nm) {
		
	}
	public boolean check_color(Color col) {
		return col == new Color(153,102,0) || col == Color.BLUE || col == Color.RED;
	}
	
		
	
}
