package homework3;

import homework3.MessageUtility;

/**
 * @author baroh
 *
 */
public class Lettuce extends Plant {
	public Lettuce() {
		super.loadImages("lettuce");
		MessageUtility.logConstractor("Lettuce", "Lettuce");
	}
	
	public Lettuce(double height,Point point,double weight) {
		this.setLocation(point);
		this.setHeight(height);
		this.setWeight(weight);
		super.loadImages("lettuce");
		MessageUtility.logConstractor("Lettuce", "Lettuce");
	}
	
	public String get_name_of_class()
	{
		return "Lettuce";
	}
	
	public String getColor() {
		return "Green";
	}
}

