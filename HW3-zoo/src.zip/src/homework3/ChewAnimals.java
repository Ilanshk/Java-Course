package homework3;
import homework3.Point;


/**
 * A class of chewing animals
 * @author Shira Cohen 211777834 & Ilan Shklover 206753550
 *
 */
public abstract class ChewAnimals extends Animal{
	/**
	 * Constructor with name, point
	 * @param name - name of the animal
	 * @param point - location of the animal
	 */
	public ChewAnimals(String name, Point point) {
		super(name, point);
	}
	
	public ChewAnimals(int size, Point point) {
		super(size,point);
	}
	
	public abstract void chew();
	/**
	 *print the sound of the chewing animal
	 */
	public void makeSound() {
		chew();
	}

}
