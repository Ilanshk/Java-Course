package homework3;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.TitledBorder;

/**
 * The area of the animals in the zoo.
 * @author Ilan Shklover 206753550, Shira Cohen 211777834
 *
 */

public class ZooPanel extends JPanel implements Runnable {
	/**
	 * array of animals
	 */
	private static Animal[] animal_array = new Animal[10];
	private static Plant plant;
	private static Meat meat;
	private static boolean isEdible = true;
	private Thread controller;
	private static int image_identifier;
	
	/**
	 * constructor of zooPanel
	 */
	public ZooPanel() {
		super();
	}
	
	
	
	/**
	 * 
	 * @param animal - new animal to add to the array of animals in the zoo.
	 * @return true if succeeded to add the new animal to the array. Else,return false.
	 */
	public static boolean set_animal_array(Animal animal) {
		animal_array[AddAnimalDialog.counter_animal]= animal;
		return true;
	}
	
	/**
	 * 
	 * @return plant-food of herbivore.
	 */
	public static Plant get_plant_food() {
		return plant;
	}
	
	public Thread get_controller() {
		return this.controller;
	}
	
	
	/**
	 * 
	 * @param p -food of herbivore(luttece or cabbege)
	 * @return true if succeeded to initialize the field 'plant'.
	 */
	public static boolean set_plant_food(Plant p) {
		if(p.get_name_of_class() == "Lettuce")
			plant = new Lettuce(5,new Point(400,300),5);
		else if(p.get_name_of_class() == "Cabbage")
			plant = new Cabbage(5,new Point(400,300),5);
		else
			plant = null;
		
		return true;
	}
	
	
	/**
	 * 
	 * @param m - object of class Meat
	 * @return true if succeeded to initialize the field 'meat'.
	 */
	public static Boolean set_meat(Meat m) {
		if(m!= null) {
			meat = new Meat(5.0,new Point(400,300),5.0);
		}
		else {
		meat = null;
		}
		return true;
		
	}
	
	public boolean set_image_identifier(int num) {
		this.image_identifier = num;
		return true;
	}
	
	public void setController() {
		this.controller = new Thread(new ZooPanel());
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		if(image_identifier == 1) {
			 try {
			 BufferedImage img = ImageIO.read(new File("C:/Users/Ilan Shklover/Desktop/assignment2_pictures/savanna.jpg"));
			 g.drawImage(img,0,0,this);
			 }
			 catch(IOException eo) {System.out.println("Can not load image");}
			 
		 }
		for(int i=0;i<AddAnimalDialog.counter_animal;i++) 		 
			 animal_array[i].drawObject(g);
		 
		 if(plant != null) {
			 plant.drawObject(g);
			 System.out.println("plant eat");
		 }
		 if(meat != null) {
			 System.out.println("meat eat");
			 meat.drawObject(g);
		 }
			 
		 
		
	}
	
	
		  
	/**
	 * 
	 * @param animal_prey - Prey animal
	 * @param animal_predator - predator animal
	 * @return true if the predator can eat the prey(according to the conditions requested)
	 */
	public boolean isCheck(Animal animal_prey,Animal animal_predator) {
		if(animal_predator.get_weight()-2*(animal_prey.get_weight())<0 && animal_predator.get_diet().canEat(animal_prey.getFoodtype())== false && isDistance(animal_prey,animal_predator) == false) {
			isEdible = false;
			return false;
		}
		return true;	
	}
	
	/**
	 * 
	 * @param animal_prey - Prey animal
	 * @param animal_predator -Predator animal
	 * @return true if the distance between the two animals is bigger than the size of the prey.
	 */
	public boolean isDistance(Animal animal_prey,Animal animal_predator) {
		if(animal_prey.calcDistance(animal_predator.getLocation()) > animal_prey.get_size())
			return false;
		return true;
	}
	 
		 
	/**
	 * 
	 * @return true if there has to be a change in the area of the animals which is the ZooPanel.(change of location or animal to remove from the panel etc.)
	 */
	//@SuppressWarnings("deprecation")
	public boolean isChange() {
		System.out.println("isChange");
		for(int i=0;i<AddAnimalDialog.counter_animal && AddAnimalDialog.counter_animal>=1;i++) {
			if(animal_array[i].getChanges() == false) {
				System.out.println("aaaaa");
				continue;
			}
			else {
				System.out.println(animal_array[i].getChanges());
				int count_alive = 0;
				if(AddAnimalDialog.counter_animal >= 1) {
					Animal[] animals_alive = new Animal[10];
					for(int k=0;k<AddAnimalDialog.counter_animal && i!=k;k++) {
						if(!(isCheck(animal_array[i],animal_array[k])==true)) {
							System.out.println("checkkkkkkkkkkkkk");
							animals_alive[count_alive] = animal_array[k];
							//ZooPanel.get_animal_array()[i].get_thread().stop();
							count_alive +=1;
						}
					}
						
					System.out.println("abc");
					if(animal_array[i].getLocation().get_x() == 0 && animal_array[i].getX_dir() == -1) {
						animal_array[i].set_X_dir(1);
						   repaint();
					}
					else if(animal_array[i].getLocation().get_x() == 800 && animal_array[i].getX_dir() == 1){
						animal_array[i].set_X_dir(-1);
						System.out.println("RIGHT BORDER");
						repaint();
					}
					if(animal_array[i].getLocation().get_y() == 0 && animal_array[i].getY_dir() == 1) {
						animal_array[i].setLocation(new Point(animal_array[i].getLocation().get_x(),animal_array[i].getLocation().get_y()+10));
						animal_array[i].set_Y_dir(-1);
					    repaint();
					}
					else if(animal_array[i].getLocation().get_y() == 600 && animal_array[i].getY_dir() == -1){
						animal_array[i].setLocation(new Point(animal_array[i].getLocation().get_x(),animal_array[i].getLocation().get_y()-10));
						animal_array[i].set_Y_dir(1);
						repaint();
					}	
						
							
					
					//repaint();
					//animal_array[i].setChanges(false);
					for(int j=0;j<count_alive;j++)
					{
						animal_array[j]=animals_alive[j];
					}
					for(int t=count_alive;t<10;t++)
					{
						animal_array[t]= null;
					}	
				if(meat != null) {
					if(Math.abs(ZooPanel.get_animal_array()[i].getLocation().get_x()-meat.getLocation().get_x())<10 && Math.abs(ZooPanel.get_animal_array()[i].getLocation().get_y()-meat.getLocation().get_y())<10) {
						if(ZooPanel.get_animal_array()[i].eat(meat)== true) {
							for(int n=0;n<AddAnimalDialog.counter_animal;n++) {
								if(ZooPanel.get_animal_array()[i].get_name_of_class() == "Lion" ||ZooPanel.get_animal_array()[i].get_name_of_class() == "Bear") {
									if(ZooPanel.get_animal_array()[i].getLocation().get_x() - meat.getLocation().get_x() > 0 && ZooPanel.get_animal_array()[i].getX_dir() == 1) { //the animal moves right and passed the meat
										ZooPanel.get_animal_array()[i].set_X_dir(-1);
										repaint();
										
									}
									if(ZooPanel.get_animal_array()[i].getLocation().get_x() - meat.getLocation().get_x() < 0 && ZooPanel.get_animal_array()[i].getX_dir() == -1) { 
										ZooPanel.get_animal_array()[i].set_X_dir(1);
										repaint();
									}
									ZooPanel.get_animal_array()[i].setLocation(meat.getLocation());
									repaint();
								}
								
							}
							this.meat = null;
							ZooPanel.get_animal_array()[i].eatInc();
							//ZooPanel.get_animal_array()[i].setChanges(false);
						}
					}
				}
				else if(plant!= null) {
					if(Math.abs(ZooPanel.get_animal_array()[i].getLocation().get_x()-plant.getLocation().get_x())<10 && Math.abs(ZooPanel.get_animal_array()[i].getLocation().get_y()-plant.getLocation().get_y())<10) {
						if(ZooPanel.get_animal_array()[i].eat(plant)== true) {
							for(int n=0;n<AddAnimalDialog.counter_animal;n++) {
								if(ZooPanel.get_animal_array()[i].get_name_of_class() == "Elephant" ||ZooPanel.get_animal_array()[i].get_name_of_class() == "Giraffe" || ZooPanel.get_animal_array()[i].get_name_of_class() == "Turtle") {
									if(ZooPanel.get_animal_array()[i].getLocation().get_x() - meat.getLocation().get_x() > 0 && ZooPanel.get_animal_array()[i].getX_dir() == 1) { //the animal moves right and passed the meat
										ZooPanel.get_animal_array()[i].set_X_dir(-1);
										repaint();
										
									}
									if(ZooPanel.get_animal_array()[i].getLocation().get_x() - meat.getLocation().get_x() < 0 && ZooPanel.get_animal_array()[i].getX_dir() == -1) { 
										ZooPanel.get_animal_array()[i].set_X_dir(1);
										repaint();
									}
									ZooPanel.get_animal_array()[i].setLocation(plant.getLocation());
									repaint();
								}
							}
							this.plant = null;
							ZooPanel.get_animal_array()[i].eatInc();
							//ZooPanel.get_animal_array()[i].setChanges(false);
						}	
				}
					
				}
					
				}
			}
		}
		if(plant!=null)
			return true;
		if(meat!= null)
			return true;
		return true;
		}
	
	
	
	/**
	 * The controller. Observes if there are  any changes in the zooPanel and updates by calling the repaint method.
	 */
	public void run() {
		if(AddAnimalDialog.counter_animal >= 1) {
			System.out.println(AddAnimalDialog.counter_animal);
			while(true) {
				isChange();
				repaint(); 
			}
		}
	}
	
		
		
    /**
     * 
     * @return The data structure in which all the animals of the zoo are located.
     */
	public static Animal[] get_animal_array() {
		return animal_array;
	}

	
	
}

