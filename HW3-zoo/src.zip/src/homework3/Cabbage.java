package homework3;

import homework3.MessageUtility;

/**
 * @author baroh
 *
 */
public class Cabbage extends Plant {
	public Cabbage() {
		MessageUtility.logConstractor("Cabbage", "Cabbage");
	}
	
	public Cabbage(double height,Point point,double weight) {
		this.setLocation(point);
		this.setHeight(height);
		this.setWeight(weight);
		super.loadImages("cabbage");
		MessageUtility.logConstractor("Cabbage", "Cabbage");
	}
	

	
	public  String get_name_of_class() {
		return "Cabbage";
	}
	
	public String getColor() {
		return "Green";
	}

}
