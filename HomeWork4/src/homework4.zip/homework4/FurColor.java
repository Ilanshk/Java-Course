package homework4;
/**
 * The bear's fur colors
 *  @author Shira Cohen 211777834 & Ilan Shklover 206753550
 *
 */
public enum FurColor {
	BLACK, WHITE, GRAY;

}
